<?php
// Database connection
$host = "localhost";
$dbname = "contact_form";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  http_response_code(500);
  echo "Database connection failed";
  exit;
}

// Sanitize and get form data
$name = htmlspecialchars(trim($_POST['name']));
$email = htmlspecialchars(trim($_POST['email']));
$subject = htmlspecialchars(trim($_POST['subject']));
$message = htmlspecialchars(trim($_POST['message']));

// Validate fields
if (empty($name) || empty($email) || empty($subject) || empty($message)) {
  http_response_code(400);
  echo "Please fill all the required fields";
  exit;
}

// Prepare SQL statement
$stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $subject, $message);

// Execute and return appropriate message
if ($stmt->execute()) {
  echo "OK"; // This triggers the success message in the HTML form
} else {
  http_response_code(500);
  echo "Something went wrong. Please try again.";
}

// Close connections
$stmt->close();
$conn->close();
?>
